Para desplegar el reto:

 * docker build -t ticketer ./app
 * docker run -p 65080:65080 -d ticketer
 * cd XSSPawn && docker compose up -d
