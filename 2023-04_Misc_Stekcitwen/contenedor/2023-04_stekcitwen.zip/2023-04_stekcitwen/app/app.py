from flask import Flask, jsonify, request, Response, make_response
from datetime import datetime
from functools import wraps
import html
import os

app = Flask(__name__)

@app.route("/")
def index():
    return "UAM alert System"

#  Estadísticas del servidor
@app.route("/uamsecretstats")
def uam_secret_stats():
    stats = {
        "uptime": str(datetime.now() - datetime.fromtimestamp(app.started_at)),
        "num_requests": app.num_requests,
        "server_version": app.server_version,
	"flag" : "UAM{593356796332566b5832467761773d3d}"
    }
    return jsonify(stats)

#  Reporte de errores
@app.route("/report", methods=["POST"])
def report():
    timestamp = request.form.get("timestamp")
    error = request.form.get("ticket_text")
    debug = request.form.get("debug", False)

    if debug.lower() == "true":
        if not os.path.exists("error_log.txt"):
            open("error_log.txt", "w").close()
            
        with open("error_log.txt", "a+") as f:
            f.write(f"{timestamp}: {error}\n")

    return "Error reportado correctamente."

def check_auth(username, password):
    return username == "admin" and password == "elseñordelanoche"

def authenticate():
    return Response(
        "Credenciales inválidas. Por favor, ingrese las credenciales correctas.",
        401,
        {'WWW-Authenticate': 'Basic realm="Ingrese sus credenciales."'}
    )

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

@app.route("/ultra_secret_error_endpoint_not_reachable_by_fuzzing")
#@requires_auth
def unsanitized_errors():

    with open("error_log.txt", "r") as f:
        errors = f.readlines()

    # Filtrar errores que contengan palabras clave específicas
    filtered_errors = []
    keywords = ["oast", "ngrok", "alert", "prompt", "request.bin","onerror","img","script","document"]
    for error in errors:
        if not any(keyword in error for keyword in keywords):
            filtered_errors.append(error)

    # Une las líneas de errores en una sola cadena separada por saltos de línea
    sanitized_errors = "<br>".join(filtered_errors)

    #response.set_cookie('flag', 'UAM{Test}')
    res = make_response(f"<h1>Últimos errores reportados:</h1><p>{sanitized_errors}</p>")
    res.set_cookie('FLAG', "UAM{6e6f745f7265616c5f6d6436}")
    return(res)

@app.route("/error")
def debug_me():

    with open("error_log.txt", "r") as f:
        errors = f.readlines()

    # Filtrar errores que contengan palabras clave específicas
    filtered_errors = []
    keywords = ["oast", "ngrok", "alert", "prompt", "request.bin","onerror","img","script","document"]
    for error in errors:
        if not any(keyword in error for keyword in keywords):
            filtered_errors.append(error)

    # Une las líneas de errores en una sola cadena separada por saltos de línea
    sanitized_errors = "<br>".join(filtered_errors)

    #response.set_cookie('flag', 'UAM{Test}')
    res = make_response(f"<h1>Últimos errores reportados:</h1><p>{sanitized_errors}</p>")
    return(res)



if __name__ == '__main__':
    app.started_at = datetime.now().timestamp()
    app.num_requests = 0
    app.server_version = "1.0"
    app.run(host="0.0.0.0",port=65080) 
