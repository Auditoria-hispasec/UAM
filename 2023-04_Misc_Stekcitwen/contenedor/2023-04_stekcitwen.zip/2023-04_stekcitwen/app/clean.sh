#!/bin/bash

while true
do
    echo "" > /usr/src/app/error_log.txt
    sleep 600 # espera 10 minutos
done
