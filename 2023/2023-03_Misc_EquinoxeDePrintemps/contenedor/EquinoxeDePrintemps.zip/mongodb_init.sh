mongosh << EOF
var admin = db.getSiblingDB('admin');
admin.auth('$MONGO_INITDB_ROOT_USERNAME', '$MONGO_INITDB_ROOT_PASSWORD');
use uam;
db.createUser({user: '$MONGODB_UAM_USER', pwd: '$MONGODB_UAM_PASS', roles:[{role:"read", db:"uam"}]});
db.uam.insertMany([
    { id: 1, name: "Oxygène", year: 1976, image: "oxygene.jpg" },
    { id: 2, name: "Équinoxe", year: 1978, image: "equinoxe.jpg" },
    { id: 3, name: "Les Chants Magnétiques", year: 1981, image: "chants.jpg" },
    { id: 4, name: "Zoolook", year: 1984, image: "zoolook.jpg" },
    { id: 5, name: "Rendez-Vous", year: 1986, image: "rendezvous.jpg" },
    { id: 6, name: "Revolutions", year: 1988, image: "revolutions.jpg" },
    { id: 7, name: "En attendant Cousteau", year: 1990, image: "cousteau.jpg" },
    { id: 8, name: "Chronologie", year: 1993, image: "chronologie.jpg" },
    { id: 9, name: "Oxygène 7-13", year: 1997, image: "oxygene7_13.jpg" },
    { id: 10, name: "Métamorphoses", year: 2000, image: "metamorphoses.jpg" },
    { id: 11, name: "A.E.R.O", year: 2004, image: "aero.jpg" },
    { id: 12, name: "Electronica 1: The Time Machine", year: 2015, image: "electro1.jpg" },
    { id: 13, name: "Electronica 2: The Heart of Noise", year: 2016, image: "electro2.jpg" },
    { id: 14, name: "Oxygène 3", year: 2016, image: "oxygene3.jpg" },
    { id: 15, name: "Equinoxe Infinity", year: 2018, image: "eqinfinity.jpg" },
    { flag: "Flag 2 cifrada hex: c857f8c84bf22fb875a702aa35f4028a70ae5e374e93bedae383cd94fa604f5276fbce8b63" },
    { key: "Clave RC4: equinoxe"}
])
EOF
