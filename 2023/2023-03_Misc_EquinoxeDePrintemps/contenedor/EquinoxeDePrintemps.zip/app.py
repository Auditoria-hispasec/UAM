#! /usr/bin/env python3
import json

from flask import (
    Flask,
    render_template,
    request,
    url_for,
)

from flask_pymongo import PyMongo
from bson import json_util

CODE_FLAG1 = "vmrEreVRQrGD4yyE"

app = Flask(__name__)
mongo = PyMongo(app, uri="mongodb://uam:uam@mongo:27017/uam")


@app.route("/hidden_file")
def hidden_file():
    return render_template("hidden.html")


@app.route("/", methods=["GET", "POST"])
def index():
    secret_code = request.form.get("code")
    error = None

    if secret_code == CODE_FLAG1:
        return render_template("flag1.html")

    if secret_code:
        if len(secret_code) != len(CODE_FLAG1):
            error = "Longitud incorrecta"
        else:
            error = "El código no es válido"

    return render_template("index.html", error=error)


@app.route("/api", methods=["POST"])
def api():
    result = {}
    query = None
    try:
        query = request.json
    except Exception:
        pass

    if query is not None:
        query_find = query.get("find", {})
        query_filter = query.get("filter", {})
        query_filter.update({"_id":0})
        if isinstance(query_find, dict) and query_find != {}:
            query_result = mongo.db.uam.find(query_find, query_filter)

    try:
        result = json.loads(json_util.dumps(query_result))
        for item in result:
            if "image" in item:
                item["image"] = url_for("static", filename=f"img/{item['image']}")
    except Exception:
        result = {}

    return result


@app.route("/b2b8ce71d541c018cc5585fa29c91a53")
def second_part():
    return render_template("albums.html")


if __name__ == "__main__":
    app.run(debug=True, threaded=True)
