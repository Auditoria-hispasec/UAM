<?php
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["curriculum"])) {
    $allowedExtensions = ["pdf", "doc", "docx"];

    $fileInfo = $_FILES["curriculum"];
    $fileName = $fileInfo["name"];

    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (in_array($fileExtension, $allowedExtensions)) {
        echo "El currículum es válido.";
    } else {
        echo "Extensión de archivo no válida. Solo se permiten archivos PDF, DOC y DOCX.";
    }
}
?>
