import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import codecs

def encrypt_message(message, key):
    cipher = AES.new(key, AES.MODE_ECB)
    ciphertext = cipher.encrypt(pad(message.encode(), AES.block_size))
    encoded_ciphertext = base64.b64encode(ciphertext).decode()
    return encoded_ciphertext

def rot_13(encoded_ciphertext):
    encrypted_rot13 = codecs.encode(encoded_ciphertext, 'rot_13')
    return encrypted_rot13

def split_into_blocks(ciphertext, block_size=16):
    blocks = []
    index = 0
    while index < len(ciphertext):
        blocks.append(ciphertext[index: index + block_size])
        index += block_size
    return blocks

def swap_blocks(blocks):
    for i in range(0, len(blocks)-1, 2):
        blocks[i], blocks[i+1] = blocks[i+1], blocks[i]

if __name__ == '__main__':
    
    message = "Texto a codificar"

    encrypted_message = encrypt_message(message, key)
    encrypted_rot13 = rot_13(encrypted_message)

    blocks = split_into_blocks(encrypted_rot13, block_size=16)
    
    swap_blocks(blocks)

    print("Mensaje original:", message)
    print("Bloques cifrados en Base64:")
    for block in blocks:
        encoded_block = base64.b64encode(block.encode()).decode()
        print(encoded_block)

