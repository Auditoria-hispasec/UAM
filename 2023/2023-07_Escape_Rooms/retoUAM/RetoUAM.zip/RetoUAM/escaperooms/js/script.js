// script.js
const slider = document.querySelector('.image-slider');
const images = document.querySelectorAll('.image-slider img');
const prevButton = document.querySelector('.prev-button');
const nextButton = document.querySelector('.next-button');
let currentImageIndex = 0;

function slideToNextImage() {
  currentImageIndex++;
  if (currentImageIndex === images.length) {
    currentImageIndex = 0;
  }
  updateSliderPosition();
}

function slideToPrevImage() {
  currentImageIndex--;
  if (currentImageIndex < 0) {
    currentImageIndex = images.length - 1;
  }
  updateSliderPosition();
}

function updateSliderPosition() {
  const translationValue = `translateX(-${currentImageIndex * 100}%)`;
  slider.style.transform = translationValue;
}

// Para cambiar de imagen al hacer clic en los botones
nextButton.addEventListener('click', slideToNextImage);
prevButton.addEventListener('click', slideToPrevImage);
