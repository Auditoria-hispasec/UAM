<!DOCTYPE html>
<html>
<head>
    <title>Iniciar sesión</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Iniciar sesión</h2>
        <form method="POST" action="login.php">
            <input type="text" name="username" placeholder="Usuario" required><br>
            <input type="password" name="password" placeholder="Contraseña" required><br>
            <input type="submit" value="Iniciar sesión">
        </form>
        <?php
            // Verificar las credenciales
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $username = $_POST['username'];
                $password = $_POST['password'];

                // Comprobar las credenciales
                if ($username === 'sh4d0w' && $password === 'Xy7#kPtG$45!zW1E') {
                    echo '<p class="success">!Enhorabuena! Has conseguido resolver el reto. Aquí tienes la flag UAM{H45-R3suelto-El-R3t0-Cr!pt0gr4f!c0}</p>';
                } else {
                    echo '<p class="error">Nombre de usuario o contraseña incorrectos. Por favor, inténtalo de nuevo.</p>';
                }
            }
        ?>
    </div>
</body>
</html>
