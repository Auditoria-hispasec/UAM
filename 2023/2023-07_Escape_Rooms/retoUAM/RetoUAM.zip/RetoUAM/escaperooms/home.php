<?php
$result = '';
if(isset($_POST['submit'])){
  $doc = new DOMDocument;
  $doc->load('r00MsS.xml');
  $xpath = new DOMXPath($doc);
  $input = $_POST['search'];
  $query = "/Rooms/Room[@ID='".$input."']";
  $result = $xpath->query($query);
}
?>
<html>
<head>
  <meta charset="UTF-8">
  <title>Título de tu página</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div>
    <div>
      <h2 id="Salas-de-Escape-Room" class="chulo-text"><center>Salas de Escape Room</center></h2>
        
      <p class="chulo2-text" align="center">Aquí encontrarás una amplia selección de emocionantes escape rooms, cada una con su propia historia intrigante y desafíos únicos. Desde mansiones embrujadas hasta viajes en el tiempo, nuestras salas te transportarán a mundos imaginarios donde tendrás que poner a prueba tu ingenio y trabajo en equipo para encontrar la salida.</p>
      <p class="chulo2-text" align="center">Nuestro objetivo es ofrecerte una experiencia inolvidable llena de emoción y diversión. Cada escape room ha sido cuidadosamente diseñada con enigmas desafiantes, acertijos intrigantes y pistas ocultas que te mantendrán absorto en la trama durante toda la aventura. Trabaja junto a tus amigos, familiares o colegas para resolver los desafíos y escapar antes de que se agote el tiempo.</p>
      <p class="chulo2-text" align="center">No importa si eres un principiante o un experto en escape rooms, nuestras instalaciones están diseñadas para satisfacer a jugadores de todos los niveles. Te proporcionaremos toda la información necesaria para reservar tu sesión y planificar una visita emocionante con tus seres queridos.</p>
      <p class="chulo2-text" align="center">Así que prepárate para una experiencia inolvidable llena de desafíos, trabajo en equipo y adrenalina. Explora nuestro sitio web, elige la sala de escape que más te llame la atención y prepárate para sumergirte en un mundo de intriga y aventura. ¡No esperes más, la diversión te espera en nuestras increíbles Escape Rooms!</p>
    </div>
  </div>

  <div class="well">
    <div class="col-lg-6"> 
      <p><b>Busca tu sala</b></p>
      <form method='POST' action=''>
        <div class="form-group"> 
          <label></label> 
          <input type="text" class="form-control" placeholder="Search by ID" name="search" value="<?php echo $input;?>"> </input> <br>
          <div align="right"> <button class="btn btn-default" name="submit" type="submit">Search</button></div>
        </div> 
      </form>
    </div>
          
    <?php
    if (is_array($result) || is_object($result)) {
        echo "<table><tr><th>ID</th><th>&nbsp;&nbsp;</th><th>Item & Description</th><th>Diff</th></tr>";
        foreach ($result as $row) {
            echo " ";
            echo "<tr><td valign=\"top\">" . $row->getElementsByTagName('ID')->item(0)->nodeValue . "</td><td>&nbsp;&nbsp;</td>";
            echo "<td valign=\"top\"><b>" . $row->getElementsByTagName('Name')->item(0)->nodeValue . "</b><br>" . $row->getElementsByTagName('Desc')->item(0)->nodeValue . "</td>";
            echo "<td valign=\"top\">" . $row->getElementsByTagName('Diff')->item(0)->nodeValue . "</td></tr>";
            echo "<tr><td colspan=3>&nbsp;</td></tr>";
        }
        echo "</table>";
    } else {
        echo "Item Not Found.";
    }
    ?>

</div>

</body>
</html>

