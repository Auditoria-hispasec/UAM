<!DOCTYPE html>
<html lang="es">
<head>
    <title>Hispa EscapeRooms</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
  <div id="navbar">
        <ul>
            <li><a href="http://escaperooms.uam">Inicio</a></li>
            <li><a href="#Sobre-nosotros">Sobre nosotros</a></li>
	    <li><a href="#Oportunidades-Laborales">Empleo</a></li>
            <li><a href="#Reseñas">Reseñas</a></li>
        </ul>
    </div>
    
    <div class="about-section">
      <h2 id="Sobre-nosotros" class="chulo-text">Sobre nosotros</h2>
      <p class="chulo2-text">
        Bienvenido a nuestra página de Escape Rooms. Nos enorgullece presentar una amplia variedad de experiencias de escape únicas que te dejarán con la adrenalina al máximo y la mente en constante alerta.
      </p>
      <p class="chulo2-text">
        Nuestros juegos están meticulosamente diseñados para desafiar tus habilidades y trabajo en equipo. Trabaja junto a tus amigos, familiares o compañeros de trabajo para descifrar pistas, encontrar objetos ocultos y desentrañar enigmas complejos.
      </p>
      <p class="chulo2-text">
        ¡Ven y únete a nosotros en una aventura emocionante! Estamos comprometidos con brindarte una experiencia completa y memorable. ¡Síguenos en nuestras redes sociales para estar al tanto de las últimas novedades!
      </p>
      <div class="social-icons">
        <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="#" target="_blank"><i class="fab fa-tiktok"></i></a>
      </div>
    </div>

<div class="image-slider">
  <img src="img/escape1.jpg" alt="Imagen 1">
  <img src="img/escape2.jpg" alt="Imagen 2">
  <img src="img/escape3.jpg" alt="Imagen 3">
  <img src="img/escape4.jpg" alt="Imagen 4">
  <img src="img/escape5.jpg" alt="Imagen 5">
</div>

<button class="prev-button">&#10094;</button>
<button class="next-button">&#10095;</button>



   <div class="job-opportunities">
      <h2 id="Oportunidades-Laborales" class="chulo-text">Oportunidades laborales</h2>
      <p class="chulo2-text">
      ¿Te apasionan los desafíos y las aventuras? ¡Únete a nuestro equipo en Hispasec Escape Rooms! Estamos buscando personas entusiastas, creativas y amantes del trabajo en equipo para formar parte de nuestro talentoso grupo.
      </p>
      <p class="chulo2-text">
      Como parte de nuestro equipo, tendrás la oportunidad de diseñar emocionantes experiencias de escape, desarrollar enigmas intrigantes y crear mundos imaginativos para nuestros clientes. Si tienes habilidades en diseño, narrativa, organización de eventos o simplemente un amor por los juegos de escape, ¡queremos conocerte!
      </p>
     <p class="chulo2-text">
     Si estás interesado en unirte a nosotros, envíanos tu currículum a través del siguiente formulario:
     </p>
    <form action="upload.php" method="post" enctype="multipart/form-data">
      <label for="curriculum">Selecciona tu currículum:</label>
      <input type="file" name="curriculum" id="curriculum" required>
      <input type="submit" value="Subir currículum">
    </form>
</div>



    <h2 id="Reseñas" class="chulo-text">Reseñas</h2>
    <div class="user-profiles">
      <div class="user-profile">
        <img src="img/imagen1.jpg" alt="Usuario 1">
        <h3>Borb3d</h3>
        <p class="chulo2-text" class="review">¡Una experiencia emocionante! Me encantó el escape room. Definitivamente volveré.</p>
        <div class="rating">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
      </div>
      <div class="user-profile">
        <img src="img/imagen2.jpg" alt="Usuario 2">
        <h3>iicrazyjr</h3>
        <p class="chulo2-text" class="review">Increíble escape room. Los enigmas eran desafiantes y la ambientación era genial.</p>
        <div class="rating">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
      </div>
      <div class="user-profile">
        <img src="img/imagen3.jpg" alt="Usuario 3">
        <h3>Mister Wh1t3</h3>
        <p class="chulo2-text" class="review">Una experiencia divertida y emocionante para compartir con amigos. ¡Muy recomendado!</p>
        <div class="rating">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
    </div>
</div>
<script src="js/script.js"></script>
</body>
</html>

