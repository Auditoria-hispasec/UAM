Flag 1 --> Inyección XPATH
Payload: 1' and substring(Secret,1,1)='E --> Hay que burteforcear para conseguir la información :

Enhorabuena!! Has encontrado la flag UAM{H@s-3xpl0t@d0-Un@-1nY3cc10n-Xp@th!}

Una vez se introduzca la flag en la web Proporciona aceso a la ruta: /571e582b0333fe8d9347eccecee35a7c

Flag 2 --> Reto python
Cadena descodificada: La contraseña es Xy7#kPtG$45!zW1E
Proporcionar la contrasela en /login.php con el usuario sh4d0w
