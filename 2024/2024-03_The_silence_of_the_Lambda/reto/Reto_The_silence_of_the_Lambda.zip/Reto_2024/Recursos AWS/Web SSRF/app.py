from flask import Flask, render_template, request
from bs4 import BeautifulSoup
import requests
import html
import os

app = Flask(__name__)

def is_valid_url(url):
    # Add your custom URL validation logic here
    # In this example, we block access to the specified URL
    blocked_url = "http://169.254.169.254/latest/meta-data/iam"
    return url != blocked_url

def count_words(url):
    if not is_valid_url(url):
        return "Access to the specified URL is not allowed."

    try:
        response = requests.get(url)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        return f"Error fetching content: {str(e)}"

    soup = BeautifulSoup(response.text, 'html.parser')
    text = soup.get_text()
    words = text.split()
    return len(words)

#Nueva función añadida para verificiar el HTML encoding. Si peta, quitarla.

def get_source_code(url):
    if not is_valid_url(url):
        return "Access to the specified URL is not allowed."

    try:
        response = requests.get(url)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        return f"Error fetching source code: {str(e)}"

    source_code = html.escape(response.text)
    return source_code

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        url = request.form['url']
        word_count = count_words(url)
        return render_template('index.html', url=url, word_count=word_count)
    return render_template('index.html')

'''
@app.route('/source')
def show_source():
    url = request.args.get('url')
    if not is_valid_url(url):
        return "Access to the specified URL is not allowed."

    try:
        response = requests.get(url)
        response.raise_for_status()
        source_code = response.text
        return render_template('source.html', url=url, source_code=source_code)
    except requests.exceptions.RequestException as e:
        return f"Error fetching source code: {str(e)}"
'''

@app.route('/source', methods=['GET'])
def show_source():
    url = request.args.get('url')
    original_url = request.args.get('original_url')

    if not is_valid_url(original_url):
        return "Access to the specified URL is not allowed."

    try:
        response = requests.get(original_url)
        response.raise_for_status()
        source_code = html.escape(response.text) # quitar el html.escape si peta
        return render_template('source.html', url=original_url, source_code=source_code)
    except requests.exceptions.RequestException as e:
        print(f"Error fetching source code for {original_url}: {str(e)}")
        return f"Error fetching source code: {str(e)}"

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=True, host='0.0.0.0', port=port)


