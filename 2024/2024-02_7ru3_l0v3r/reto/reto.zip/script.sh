#!/bin/bash

apt-get update && apt-get install -y curl

while true; do 
    curl -k -s -m 1 https://website:443 -d "love_code=nuncaconseguiranentrarenlazonadelamor" && sleep 0.5
done
