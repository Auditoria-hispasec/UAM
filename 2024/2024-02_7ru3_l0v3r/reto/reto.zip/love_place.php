<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>💕 I'm in love... 💕</title>
    <!-- <link rel="stylesheet" href="/static/styles/love.css"> -->
    <link rel="stylesheet" href="/static/styles/style.css">
    <link href="https://fonts.cdnfonts.com/css/g-gelembung" rel="stylesheet">
    <script src="/static/js/script.js"></script>
</head>

<body>

    <?php
    session_start();

    if (!isset($_SESSION["lover_user"]) || !isset($_SESSION["timeout"])) {
        header('Location: index.php');
        exit();
    }
    ?>

    <h1>Quieres conocer a tu amor verdadero??</h1>
    <h2>Haga click debajo para conocerlo!</h2>
    <div id="numeroAleatorio">
    </div>
    <form action="download.php" method="POST">
        <input type="hidden" name="filename" value="carta de amor.txt">
        <button type="submit" name="download">-_-</button>
    </form>
</body>

</html>