<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>💕 I'm in love... 💕</title>
    <link rel="stylesheet" href="/static/styles/style.css">
    <link href="https://fonts.cdnfonts.com/css/g-gelembung" rel="stylesheet">
</head>

<body>

    <?php
    session_start();

    // TODO: Eliminar el resto de variables de entono sensibles en .love_environment dentro del directorio de configuracion de apache
    $secret_code = getenv('codigo');

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $love_code = $_POST['love_code'];
        if ($love_code === $secret_code) {
            $_SESSION["lover_user"] = true;
            $_SESSION["timeout"] = time();
            header("Location: love_place.php");
            exit();
        } else {
            header("Location: error.html");
            exit();
        }
    }
    ?>

    <img src="/static/images/ricardio.png" height="300px">
    <h1>¿Serás capaz de acceder a mi corazón?</h1>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="main_div">
            <input type="text" name="love_code" id="love_code" placeholder="Send me the love code..."><br><br>
        </div>
        <input type="submit" value="Send some love" id="love_sender">
    </form>
</body>

</html>