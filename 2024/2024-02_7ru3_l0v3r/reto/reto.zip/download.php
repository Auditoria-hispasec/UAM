<?php
session_start();
$whitelist = array("index.php", "/etc/apache2/.love_environment", "/etc/passwd", "love_place.php", "carta de amor.txt");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_SESSION["lover_user"]) || !isset($_COOKIE['PHPSESSID'])) {
        http_response_code(403);
        exit();
    }

    $archivo = isset($_POST['filename']) ? $_POST['filename'] : '';

    $ruta = '/var/www/' . $archivo;

    $encontrada = true;

    foreach ($whitelist as $validate_word) {
        // Verifica si la cadena contiene la palabra actual
        if (strpos($ruta, $validate_word) !== false) {
            $encontrada = false;
            break;
        }
    }

    if ($encontrada) {
        echo 'Ruta no permitida, prueba con otra (:';
    } else {
        $filtered_archivo = str_replace('../', '', $archivo);
        $ruta = '/var/www/' . $filtered_archivo;
        if (file_exists($ruta)) {
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $archivo . '"');
            header('Content-Length: ' . filesize($ruta));
            readfile($ruta);
        } else {
            echo 'No existe la carta de amor ' . $filtered_archivo;
        }
    }
}
