import discord # Discord library.
from discord import Member # Discord library.
from discord import embeds # Library for kick, bans, etc.
from discord.ext import commands # Discord library.
from discord.ext.commands import has_permissions, MissingPermissions # Library for kick, bans, etc.
from discord.utils import get # Role library.

intents = discord.Intents.default()
intents.members = True

client = commands.Bot(command_prefix = '!', intents=intents)

@client.event
async def on_ready():
    await client.change_presence(status=discord.Status.online, activity=discord.Game('Agendar'))
    print("The bot is now ready for use!")
    print("-----------------------------")

@client.event
async def on_member_join(member):
    user = await client.fetch_user(member.id)
    await user.send("FLAG1\n\nBienvenido al servidor, puede que seas definitif juacker desde otro lugar; para realizar tu verificación introduce !verify")

@client.event
async def on_message(message):
    if message.content == "!verify":
        await message.channel.send("Perfecto, primera pregunta; indica el identificador de vuelo de tu último vuelo; para introducirlo simplemente digamelo :)")
    if message.content == "v72919":
        await message.channel.send("Puede que sí seas tú, aún así tengo que realizar la verificación completa; indicame el nombre del hotel al que fuiste.")
    if message.content == "Away Hostel":
        await message.channel.send("Bienvenido Juacker; aquí tienes tu lista de tareas:\n-FLAG2\n-Romper la web del hexágono.\n-Hackear el ecosistema.")

client.run('MTExMzc1MTc1NzQ3MDgzODgzNA.GboLlX.KOYoY97r2526JDQnwnU_Qelb3bqZSJN1q_M_JU')